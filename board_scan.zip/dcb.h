
#ifndef DCB_H_   /* Include guard */
#define DCB_H_

#include <stdint.h>


/*Module Pin defines*/
#define BLOCK_ADDR0 19//13
#define BLOCK_ADDR1 20//10
#define BLOCK_ADDR2 22//9

#define ADDR0 23//16
#define ADDR1 24//17
#define ANALOG_SELECT0  14//23
#define ANALOG_SELECT1  18//24
#define EN_PD 19//31
#define EN_AMP 20//29
#define EN_BLOCK 25//30
#define EN_SYS 13//20


#define INIT_CHANGE_VALUE 0xFF
#define MAX_NUMBER_OF_CHANGES 8
#define BLOCK_NUM 8
#define NUM_OF_CELLS 64
#define BITS_IN_BYTE 8
#define BIT(n) (0x1U <<(n))

/*--Function decalraitions--*/
int set_block(int block_num);
int set_addr(int addr_num);
int set_analog_mux(int ana_num);

//int read_adc(int *data);

int init_dcb();
//int new_move_algo();
int enable_pd_block(uint8_t block_num);
int read_block();
int read_board_position();


/*-- Global Variables--*/
uint8_t change_array[4];
uint8_t new_pos[8];
uint8_t current_position[8]; 
uint8_t new_position[8]; // Holds the new board state

uint8_t board_lookup[32] = { 0,    //[0,0,0,0,0,0,0,0],
                            4,    //[0,0,0,0,0,1,0,0],
                            8,    //[0,0,0,0,1,0,0,0],
                            12,   //[0,0,0,0,1,1,0,0],
                            66,   //[0,1,0,0,0,0,1,0],
                            70,   //[0,1,0,0,0,1,1,0],
                            74,   //[0,1,0,0,1,0,1,0],
                            78,   //[0,1,0,0,1,1,1,0],
                            16,   //[0,0,0,1,0,0,0,0],
                            20,   //[0,0,0,1,0,1,0,0],
                            24,   //[0,0,0,1,1,0,0,0],
                            28,   //[0,0,0,1,1,1,0,0],
                            82,   //[0,1,0,1,0,0,1,0],
                            86,   //[0,1,0,1,0,1,1,0],
                            90,   //[0,1,0,1,1,0,1,0],
                            94,   //[0,1,0,1,1,1,1,0],
                            33,   //[0,0,1,0,0,0,0,1],
                            37,   //[0,0,1,0,0,1,0,1],
                            41,   //[0,0,1,0,1,0,0,1],
                            45,   //[0,0,1,0,1,1,0,1],
                            99,   //[0,1,1,0,0,0,1,1],
                            103,  //[0,1,1,0,0,1,1,1],
                            107,  //[0,1,1,0,1,0,1,1],
                            111,  //[0,1,1,0,1,1,1,1],
                            46,   //[0,0,1,1,0,0,0,1],
                            53,   //[0,0,1,1,0,1,0,1],
                            57,   //[0,0,1,1,1,0,0,1],
                            61,   //[0,0,1,1,1,1,0,1],
                            115,  //[0,1,1,1,0,0,1,1],
                            119,  //[0,1,1,1,0,1,1,1],
                            123,  //[0,1,1,1,1,0,1,1],
                            127,  //[0,1,1,1,1,1,1,1]
                            }; 
#endif