#include <stdint.h>
#include "dcb.h"
/*Includes for GPIO*/
#include "nrf_gpio.h"
#include "nrf_drv_gpiote.h"
/**/

//int compare_block(uint8_t *current_state, uint8_t *new_state);
//int move_algo(uint8_t move_state);

int init_dcb() 
{
  int i;
  /*Init GPIO*/
  nrf_gpio_cfg_output(BLOCK_ADDR0);
  nrf_gpio_cfg_output(BLOCK_ADDR1);
  nrf_gpio_cfg_output(BLOCK_ADDR2);
  
  nrf_gpio_cfg_output(ADDR0);
  nrf_gpio_cfg_output(ADDR1);  

  nrf_gpio_cfg_output(EN_PD);  
  nrf_gpio_cfg_output(EN_AMP);
  nrf_gpio_cfg_output(EN_BLOCK);
  nrf_gpio_cfg_output(EN_SYS);

  read_board_position();

  for(i = 0; i < NUM_OF_CELLS / 8; i++)
    current_position[i] = 0;
}

int set_addr(int addr_num)
{
  if ((addr_num < 4) && (addr_num >= 0))
  {
    switch(addr_num)
    {
      case 0:
            nrf_gpio_pin_clear(BLOCK_ADDR0);
            nrf_gpio_pin_clear(BLOCK_ADDR1);
        break;
      case 1:
            nrf_gpio_pin_set(BLOCK_ADDR0);
            nrf_gpio_pin_clear(BLOCK_ADDR1);
        break;
      case 2:
            nrf_gpio_pin_clear(BLOCK_ADDR0);
            nrf_gpio_pin_set(BLOCK_ADDR1);
        break;
      case 3:
            nrf_gpio_pin_set(BLOCK_ADDR0);
            nrf_gpio_pin_set(BLOCK_ADDR1);
        break;        
    }
      return 0;
  }

    else 
      return 1;
}

int set_analog_mux(int ana_num)
{
  if ((ana_num < 4) && (ana_num >= 0))
  {
    switch(ana_num)
    {
      case 0:
            nrf_gpio_pin_clear(ANALOG_SELECT0);
            nrf_gpio_pin_clear(ANALOG_SELECT1);
        break;
      case 1:
            nrf_gpio_pin_set(ANALOG_SELECT0);
            nrf_gpio_pin_clear(ANALOG_SELECT1);
        break;
      case 2:
            nrf_gpio_pin_clear(ANALOG_SELECT0);
            nrf_gpio_pin_set(ANALOG_SELECT1);
        break;
      case 3:
            nrf_gpio_pin_set(ANALOG_SELECT0);
            nrf_gpio_pin_set(ANALOG_SELECT1);
        break;  
    }

     return 0;
  }   
   
    else 
      return 1;
}

int set_block(int block_num)
{
  if ((block_num < 8) && (block_num >= 0))
  {
    switch(block_num)
    {
      case 0:
            nrf_gpio_pin_clear(BLOCK_ADDR0);
            nrf_gpio_pin_clear(BLOCK_ADDR1);
            nrf_gpio_pin_clear(BLOCK_ADDR2);
            break;
      case 1:
            nrf_gpio_pin_set(BLOCK_ADDR0);
            nrf_gpio_pin_clear(BLOCK_ADDR1);
            nrf_gpio_pin_clear(BLOCK_ADDR2);          
            break;
      case 2:
            nrf_gpio_pin_clear(BLOCK_ADDR0);
            nrf_gpio_pin_set(BLOCK_ADDR1);
            nrf_gpio_pin_clear(BLOCK_ADDR2);
            break;
      case 3:
            nrf_gpio_pin_set(BLOCK_ADDR0);
            nrf_gpio_pin_set(BLOCK_ADDR1);
            nrf_gpio_pin_clear(BLOCK_ADDR2);

            break;
      case 4:
            nrf_gpio_pin_clear(BLOCK_ADDR0);
            nrf_gpio_pin_clear(BLOCK_ADDR1);
            nrf_gpio_pin_set(BLOCK_ADDR2);
            break;
      case 5:
            nrf_gpio_pin_set(BLOCK_ADDR0);
            nrf_gpio_pin_clear(BLOCK_ADDR1);
            nrf_gpio_pin_set(BLOCK_ADDR2);
            break;
      case 6:
            nrf_gpio_pin_clear(BLOCK_ADDR0);
            nrf_gpio_pin_set(BLOCK_ADDR1);
            nrf_gpio_pin_set(BLOCK_ADDR2);
            break;
      case 7:
            nrf_gpio_pin_set(BLOCK_ADDR0);
            nrf_gpio_pin_set(BLOCK_ADDR1);
            nrf_gpio_pin_set(BLOCK_ADDR2);
            break; 
      
      }

      return 0;
   }
   else
      return 1;
}
//
//
////current_position
//
int read_board_position()
{
  int index;
  uint8_t line_val0;
  uint8_t line_val1;
  uint8_t new_position[8] = {0};
  _Bool *adc_val;

  nrf_gpio_pin_set(EN_SYS);
  nrf_gpio_pin_set(EN_PD);
  nrf_gpio_pin_set(EN_AMP);
  nrf_gpio_cfg_output(EN_BLOCK);

  /* Scanning the board 32 times and each 
  * time get 2 cells at a time
  */
  for (index = 0; index < NUM_OF_CELLS/2; index++)
  {      
    set_block(board_lookup[index] >> 4);
    set_addr(board_lookup[index] >> 2) & 3;
    set_analog_mux(board_lookup[index]) & 3;

    nrf_gpio_pin_set(EN_AMP);
//    if (!read_adc(*adc_val))                            // read 2 cells  
//      return 1;
//    
//    if (adc_val[0] == true)
//      line_val0 = line_val0 | BIT(index % BITS_IN_BYTE);  // set bit      
//
//    if (adc_val[1] == true)
//      line_val1 = line_val1 | BIT(index % BITS_IN_BYTE); // set bit   

    if(index % BITS_IN_BYTE == 0)  // if scanned a line - update the array
    {
      new_position[2 * index / BITS_IN_BYTE] = line_val0;
      new_position[(2 * index / BITS_IN_BYTE) + 1] = line_val1;
    }      
  }
  nrf_gpio_pin_clear(EN_PD);
  nrf_gpio_pin_clear(EN_BLOCK); 
  nrf_gpio_pin_clear(EN_AMP);
  nrf_gpio_pin_clear(EN_SYS);
 
  return 0;
}



//
//int compare_block(uint8 *current_state, uint8 *New_state)
//{
//  int i,j;
//  uint8_t line;
//  uint8_t column;
//  uint8_t current_bit;
//  uint8_t new_bit;
//  uint8_t change_location;
//  uint8_t change;
//  bool flag_new_change;
//
// /*
//  * change_array [[change_val],[0]]      
//  * change_array [[change_counter],[1]] 
//  */
//  uint8_t change_array[8][2];
//  
//  for (i=0; i<8; i++)
//    for (j=0; j<2; j++)
//     change_array[i][j] = INIT_CHANGE_VALUE;
//
//
//
//  for (line = 0; line < 8; line++)
//  {
//    if (current_state[line] != new_state[line])	
//    {
//      for(column = 0; column < 8; column++)
//      {
//        current_bit = (current_state[line] >> column) & 0x01 ;
//        new_bit = (new_state[line] >> column) & 0x01 ;
//        if(current_bit != new_bit);
//        {
//          //change_val structure [1(added)/0(removed), col2,col1,col0,0, line2, line1, line0] 
//          change_location = line + column << 4; 
//          
//          if (new_bit) // a piece was placed on the squre
//            change_location = change_location | 0x80; 
//
//          flag_new_change = true;
//          for(change = 0; change < MAX_NUMBER_OF_CHANGES; change++) 
//          {
//            if (change_array[change][0] == change_location)
//            {	
//                /* ADD 2 in case of change and subtruct 1 from everybody later so
//                   eventually add 1 to the new changes.
//                 */
//                change_array [change][1] = change_array[change][1] + 2;                              
//                flag_new_change = false;
//                break; // ---- verify it isn't exiting the function but only the loop---
//            }
//          }
//
//          if (flag_new_change) // if the change happned for the first time.
//          {
//            for(change = 0; change < MAX_NUMBER_OF_CHANGES; change++) 
//            {
//              if (change_array[change][0] == INIT_CHANGE_VALUE)
//              {	
//                  change_array[change][0] = change_location;
//                  change_array[change][1] = 0x01;                 
//                  break;
//              }
//            }
//          }
//        }
//      }	
//    }		
//  }
//
//  for(change = 0; change < MAX_NUMBER_OF_CHANGES; change++) 
//  {
//      if (change_array[change][0]!=INIT_CHANGE_VALUE)
//      {	
//        if (change_array[change][1] == 0x00)
//        {
//            change_array[change][0]==INIT_CHANGE_VALUE;
//            change_array[change][1]==INIT_CHANGE_VALUE;
//        }
//        else
//        {
//          --change_array[change][1];
//        }
//      }
//      if (change_array[change][1] > debounce_Val)
//      {
//        Move_Algo (uint8 change_array [change][0]);
//        change_array[change][0]==INIT_CHANGE_VALUE;
//        change_array[change][1]==INIT_CHANGE_VALUE;
//      }
//  }
//}
//
////
////
////
////int read_board_position()
////{
////  uint8_t block;
////  uint8_t addr;
////  int *val;
////
////  for (block = 0; block < 8; block ++)
////  {
////    for (addr = 0; addr < 4 ; addr ++)
////    {
////      if ((block == 0) || (block == 1))
////        set_analog_mux(0);
////      if ((block == 2) || (block == 3))
////        set_analog_mux(1);
////      if ((block == 4) || (block == 5))
////        set_analog_mux(2);
////      if ((block == 6) || (block == 7))
////        set_analog_mux(3);
////
////      nrf_gpio_pin_set(EN_AMP);
////      read_adc(*val); // read 2 cells  
////      nrf_gpio_pin_clear(EN_AMP);
////      
////      if (block >> 2)     //It's block 4-7
////      {
////        if (val[0] > THRESHOLD)
////          current_position[block - 4] = current_position[block - 4]  | BIT(addr + 4);  // set bit
////        else
////          current_position[block - 4] = current_position[block - 4]  & ~BIT(addr + 4);  // clear bit
////        
////        if (val[1] > THRESHOLD)        
////           current_position[block - 3] = current_position[block - 3]  | BIT(addr + 4);  // set bit
////        else
////          current_position[block - 3] = current_position[block - 3]  & ~BIT(addr + 4);  // clear bit     
////
////      }
////      else              //It's block 0-3
////      {
////        if (val[0] > THRESHOLD)
////          current_position[block] = current_position[block]  | BIT(addr + 4);  // set bit
////        else
////          current_position[block] = current_position[block]  & ~BIT(addr + 4);  // clear bit
////        
////        if (val[1] > THRESHOLD)        
////           current_position[block] = current_position[block]  | BIT(addr + 4);  // set bit
////        else
////          current_position[block] = current_position[block]  & ~BIT(addr + 4);  // clear bit    
////      }
////    }
////  }
////}
//
//
//
//int read_adc(*val)
//{
// 
//  
//
//
//   
//}


